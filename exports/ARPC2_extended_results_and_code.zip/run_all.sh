#!/usr/bin/env bash
set -euo pipefail
cd /workspace/liver-fibrosis-analysis
source /workspace/.cloud-onboarding/liver-fibrosis-analysis/activate.sh
mkdir -p logs
python scripts/download_geo.py --accession GSE159676 --accession GSE84044 2>&1 | tee logs/download_first_stage.log
python scripts/parse_geo.py GSE159676 2>&1 | tee logs/parse_GSE159676.log
python scripts/parse_geo.py GSE84044 2>&1 | tee logs/parse_GSE84044.log
python scripts/analyze_first_stage.py GSE159676 2>&1 | tee logs/analyze_GSE159676.log
python scripts/analyze_first_stage.py GSE84044 2>&1 | tee logs/analyze_GSE84044.log
python scripts/qc_summary.py 2>&1 | tee logs/qc_summary.log
python scripts/download_zenodo_psc.py 2>&1 | tee logs/download_zenodo_psc.log
python scripts/analyze_zenodo_psc.py 2>&1 | tee logs/analyze_zenodo_psc.log
python scripts/analyze_candidate_programs.py 2>&1 | tee logs/analyze_candidate_programs.log
python scripts/download_geo.py --accession GSE239283 2>&1 | tee logs/download_GSE239283.log
python scripts/parse_geo.py GSE239283 2>&1 | tee logs/parse_GSE239283.log
python scripts/analyze_organoids.py 2>&1 | tee logs/analyze_GSE239283.log
python scripts/download_geo.py --accession GSE247128 2>&1 | tee logs/download_GSE247128.log
python scripts/parse_geo.py GSE247128 2>&1 | tee logs/parse_GSE247128.log
if [ ! -s data/raw/GSE136103/GSE136103_RAW.tar ]; then
  curl --fail --location --silent --show-error --proto '=https' --tlsv1.2 \
    https://ftp.ncbi.nlm.nih.gov/geo/series/GSE136nnn/GSE136103/suppl/GSE136103_RAW.tar \
    --output data/raw/GSE136103/GSE136103_RAW.tar
  sha256sum data/raw/GSE136103/GSE136103_RAW.tar > data/raw/GSE136103/GSE136103_RAW.tar.sha256
  tar -xf data/raw/GSE136103/GSE136103_RAW.tar -C data/raw/GSE136103
fi
python scripts/analyze_gse136103_sc.py 2>&1 | tee logs/analyze_GSE136103.log
python scripts/write_reports.py 2>&1 | tee logs/write_reports.log
echo "Completed ARPC2 GEO workflow. See reports/ and results/."
