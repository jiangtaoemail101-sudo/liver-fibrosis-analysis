#!/usr/bin/env python3
"""GSE239283 organoid ARPC2 analysis using donor-level, vehicle/CNT samples."""
from __future__ import annotations
import gzip
import hashlib
import json
import re
from pathlib import Path
from urllib.request import Request, urlopen
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy.io import mmread
from scipy.stats import mannwhitneyu

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data/raw/GSE239283/10x"
META = ROOT / "data/processed/GSE239283/sample_metadata.csv"

def fetch(url: str, path: Path) -> dict:
    url = url.replace("ftp://ftp.ncbi.nlm.nih.gov", "https://ftp.ncbi.nlm.nih.gov")
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        request = Request(url, headers={"User-Agent": "ARPC2-GEO-reproducible-analysis/1.0"})
        with urlopen(request, timeout=120) as source, path.open("wb") as target:
            while block := source.read(1024 * 1024): target.write(block)
    return {"url": url, "path": str(path.relative_to(ROOT)), "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}

def load_sample(row: pd.Series) -> dict:
    title = str(row["Sample_title"])
    sample_dir = RAW / row.name
    urls = {"barcodes": row["Sample_supplementary_file_1"], "features": row["Sample_supplementary_file_2"], "matrix": row["Sample_supplementary_file_3"]}
    files = {kind: sample_dir / Path(url).name for kind, url in urls.items()}
    manifest = [fetch(url, files[kind]) for kind, url in urls.items()]
    with gzip.open(files["features"], "rt", encoding="utf-8") as handle:
        features = pd.read_csv(handle, sep="\t", header=None)
    names = features.iloc[:, 1].astype(str).str.upper() if features.shape[1] > 1 else features.iloc[:, 0].astype(str).str.upper()
    positions = np.flatnonzero(names.to_numpy() == "ARPC2")
    if len(positions) != 1:
        raise ValueError(f"{row.name}: expected exactly one ARPC2 feature, found {len(positions)}")
    with gzip.open(files["matrix"], "rb") as handle:
        matrix = mmread(handle).tocsr()
    counts = np.asarray(matrix.getrow(int(positions[0])).todense()).ravel().astype(float)
    library_size = np.asarray(matrix.sum(axis=0)).ravel()
    valid = library_size > 0
    normalized = np.log1p(counts[valid] / library_size[valid] * 10000)
    donor = re.search(r"(?:PSC|nonPSC)_(\d+)", title, flags=re.I)
    if donor is None: raise ValueError(f"Could not infer donor from {title}")
    disease = "PSC" if title.lower().startswith("psc_") else "nonPSC"
    return {"sample_id": row.name, "title": title, "disease": disease, "donor": donor.group(1), "condition": "Vehicle/CNT", "n_cells": int(valid.sum()), "ARPC2_mean_log1p_cpm": float(normalized.mean()), "ARPC2_fraction_detected": float(np.mean(counts[valid] > 0)), "files": manifest}

def main():
    metadata = pd.read_csv(META, index_col=0)
    vehicle = metadata[metadata["Sample_title"].astype(str).str.endswith("_CNT")].copy()
    if len(vehicle) != 8: raise ValueError(f"Expected eight vehicle/CNT samples, found {len(vehicle)}")
    records = [load_sample(row) for _, row in vehicle.iterrows()]
    table = pd.DataFrame(records)
    out = ROOT / "results/tables/GSE239283_organoid_ARPC2_vehicle_donor.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    table.drop(columns=["files"]).to_csv(out, index=False)
    (ROOT / "data/raw/GSE239283/10x_download_manifest.json").write_text(json.dumps(records, indent=2) + "\n")
    groups = {key: value["ARPC2_mean_log1p_cpm"] for key, value in table.groupby("disease")}
    test = mannwhitneyu(groups["PSC"], groups["nonPSC"], alternative="two-sided", method="asymptotic")
    statistics = pd.DataFrame([{"dataset": "GSE239283", "condition": "Vehicle/CNT", "unit": "donor", "n_PSC": len(groups["PSC"]), "n_nonPSC": len(groups["nonPSC"]), "PSC_median": np.median(groups["PSC"]), "nonPSC_median": np.median(groups["nonPSC"]), "median_difference_nonPSC_minus_PSC": np.median(groups["nonPSC"]) - np.median(groups["PSC"]), "mann_whitney_U": test.statistic, "p_value": test.pvalue}])
    statistics.to_csv(ROOT / "results/tables/GSE239283_organoid_ARPC2_statistics.csv", index=False)
    with pd.ExcelWriter(ROOT / "results/tables/GSE239283_organoid_ARPC2_statistics.xlsx") as writer:
        statistics.to_excel(writer, sheet_name="statistics", index=False)
        table.drop(columns=["files"]).to_excel(writer, sheet_name="donor_values", index=False)
    fig, ax = plt.subplots(figsize=(4.8, 4.2))
    sns.boxplot(data=table, x="disease", y="ARPC2_mean_log1p_cpm", order=["nonPSC", "PSC"], palette={"nonPSC": "#4C78A8", "PSC": "#E45756"}, showfliers=False, ax=ax)
    sns.stripplot(data=table, x="disease", y="ARPC2_mean_log1p_cpm", order=["nonPSC", "PSC"], color="#222222", size=5, jitter=.1, ax=ax)
    ax.set(xlabel="Organoid donor group", ylabel="ARPC2 mean log1p(CP10K)", title="GSE239283, Vehicle/CNT only")
    ax.text(0.98, 0.98, f"Mann–Whitney P={test.pvalue:.3g}; n=4/4 donors", transform=ax.transAxes, ha="right", va="top", fontsize=8)
    sns.despine()
    stem = ROOT / "results/figures/Figure_E_GSE239283_ARPC2_vehicle"
    for suffix, kwargs in (("pdf", {}), ("svg", {}), ("tiff", {"dpi": 600}), ("png", {"dpi": 300})):
        fig.savefig(stem.with_suffix("." + suffix), bbox_inches="tight", **kwargs)
    plt.close(fig)
    print(statistics.to_string(index=False))

if __name__ == "__main__":
    main()
