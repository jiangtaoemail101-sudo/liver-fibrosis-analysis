#!/usr/bin/env python3
"""Parse GEO series matrix expression and sample metadata."""
from __future__ import annotations
import argparse
import gzip
import json
from io import StringIO
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

def read_lines(path: Path):
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        yield from handle

def parse_matrix(path: Path):
    meta, table, platforms, in_table = {}, [], [], False
    for line in read_lines(path):
        line = line.rstrip("\n")
        if line.startswith("!Sample_platform_id") and "\t" in line:
            platforms.extend(value.strip('"') for value in line.split("\t")[1:])
        if line.startswith("!Sample_") and "\t" in line:
            key, values = line[1:].split("\t", 1)
            meta.setdefault(key, []).extend(value.strip('"') for value in values.split("\t"))
        if line == "!series_matrix_table_begin":
            in_table = True
            continue
        if line == "!series_matrix_table_end":
            break
        if in_table:
            table.append(line)
    if not table:
        raise ValueError(f"No series matrix table found in {path}")
    matrix = pd.read_csv(StringIO("\n".join(table)), sep="\t", dtype=str, na_values=["null", "NA", ""])
    matrix = matrix.set_index(matrix.columns[0])
    for column in matrix.columns:
        matrix[column] = pd.to_numeric(matrix[column], errors="coerce")
    samples = pd.DataFrame({k: v for k, v in meta.items() if len(v) == len(matrix.columns)}, index=matrix.columns)
    samples.index.name = "sample_id"
    samples["platform_id"] = platforms if len(platforms) == len(samples) else ""
    samples["sample_id"] = samples.index
    return matrix, samples, {"platform_ids": sorted(set(platforms)), "n_features": matrix.shape[0], "n_samples": matrix.shape[1]}

def expand_characteristics(samples: pd.DataFrame) -> pd.DataFrame:
    expanded = {}
    for column in samples.columns:
        if "characteristics" not in column:
            continue
        for sample_id, raw in samples[column].items():
            for item in str(raw).split(";"):
                if ":" in item:
                    key, value = item.split(":", 1)
                    expanded.setdefault(key.strip().lower().replace(" ", "_"), {})[sample_id] = value.strip()
    for key, values in expanded.items():
        samples[key] = pd.Series(values)
    return samples

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("accession")
    accession = parser.parse_args().accession
    path = ROOT / "data" / "raw" / accession / f"{accession}_series_matrix.txt.gz"
    matrix, samples, summary = parse_matrix(path)
    samples = expand_characteristics(samples)
    output = ROOT / "data" / "processed" / accession
    output.mkdir(parents=True, exist_ok=True)
    matrix.to_csv(output / "expression_matrix.csv.gz", compression="gzip")
    samples.to_csv(output / "sample_metadata.csv")
    (output / "matrix_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
