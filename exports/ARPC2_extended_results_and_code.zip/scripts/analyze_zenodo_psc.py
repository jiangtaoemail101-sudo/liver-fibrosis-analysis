#!/usr/bin/env python3
"""Analyze the Zenodo PSC/PBC/MASLD count_summary.tsv cohort."""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import kruskal, spearmanr
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data/raw/zenodo_13990103"
OUT = ROOT / "results/tables"
GENES = {
    "ARPC2":"ENSG00000177463", "ACTR2":"ENSG00000138071", "ACTR3":"ENSG00000112312", "ARPC1A":"ENSG00000107731", "ARPC1B":"ENSG00000116704", "ARPC3":"ENSG00000148411", "ARPC4":"ENSG00000136011", "ARPC5":"ENSG00000149273",
    "MKL1":"ENSG00000196588", "SRF":"ENSG00000112658", "TAGLN":"ENSG00000149591", "CNN1":"ENSG00000130176", "MYL9":"ENSG00000101335", "TPM2":"ENSG00000198467", "CALD1":"ENSG00000122786",
    "ACTA2":"ENSG00000107796", "COL1A1":"ENSG00000108821", "COL1A2":"ENSG00000164692", "COL3A1":"ENSG00000168542", "FN1":"ENSG00000115414", "CCN2":"ENSG00000118523", "TIMP1":"ENSG00000102265", "LOX":"ENSG00000113083", "PDGFRB":"ENSG00000113721",
    "KRT19":"ENSG00000073008", "KRT7":"ENSG00000135480", "SOX9":"ENSG00000125398", "EPCAM":"ENSG00000119888", "SPP1":"ENSG00000118785", "MUC1":"ENSG00000185499",
    "SNAI2":"ENSG00000019549", "SNAI1":"ENSG00000124216", "ZEB1":"ENSG00000148516", "ZEB2":"ENSG00000169554", "TWIST1":"ENSG00000122691", "CDH1":"ENSG00000039068", "CDH2":"ENSG00000170558", "VIM":"ENSG00000026025", "TJP1":"ENSG00000104067"
}
MRTF_PROXY = ["ACTA2", "TAGLN", "CNN1", "MYL9", "TPM2", "CALD1", "COL1A1", "COL3A1", "CCN2", "FN1"]
EMT_PROXY = ["SNAI2", "SNAI1", "ZEB1", "ZEB2", "TWIST1", "CDH2", "VIM", "FN1"]

def score(frame, genes):
    available = [g for g in genes if g in frame.index and frame.loc[g].notna().sum() >= 4]
    z = frame.loc[available].apply(lambda x: (x-x.mean())/x.std(ddof=1) if x.std(ddof=1)>0 else x*0, axis=1)
    return z.mean(axis=0), available

def save_figure(fig, stem):
    for ext, kw in (("pdf",{}),("svg",{}),("tiff",{"dpi":600}),("png",{"dpi":300})):
        fig.savefig(stem.with_suffix("."+ext), bbox_inches="tight", **kw)
    plt.close(fig)

def main():
    counts = pd.read_csv(RAW / "count_summary.tsv", sep="\t", index_col=0)
    clinical = pd.read_csv(RAW / "clinical_data.tsv", sep="\t")
    clinical["sample"] = clinical["sample"].astype(str)
    samples = [s for s in clinical["sample"] if s in counts.columns]
    clinical = clinical.set_index("sample").loc[samples]
    counts = counts[samples]
    library = counts.sum(axis=0)
    expr = np.log2(counts.divide(library, axis=1) * 1e6 + 1)
    mapping = pd.DataFrame({"gene_symbol": list(GENES), "ensembl_id": list(GENES.values()), "detected_in_count_matrix": [e in expr.index for e in GENES.values()]})
    mapping.to_csv(OUT / "zenodo_gene_mapping.csv", index=False)
    found = {gene: ensembl for gene, ensembl in GENES.items() if ensembl in expr.index}
    gene_expr = expr.loc[list(found.values())].copy(); gene_expr.index = list(found.keys())
    gene_expr.to_csv(ROOT / "data/processed/zenodo_13990103_gene_expression_log2cpm.csv")
    psc = clinical.diagnosis.eq("PSC")
    stage_rows, group_rows = [], []
    for gene in found:
        valid = psc & clinical.fibrosis.notna() & gene_expr.loc[gene].notna()
        if valid.sum() >= 4 and clinical.loc[valid, "fibrosis"].nunique() >= 2:
            rho, p = spearmanr(clinical.loc[valid, "fibrosis"], gene_expr.loc[gene, valid])
            stage_rows.append({"dataset":"Zenodo_13990103", "diagnosis":"PSC", "gene":gene, "n":int(valid.sum()), "spearman_rho":rho, "p_value":p})
        groups = [gene_expr.loc[gene, clinical.diagnosis.eq(d)].dropna() for d in ("PSC","PBC","MASLD")]
        if all(len(x) >= 2 for x in groups):
            test = kruskal(*groups)
            group_rows.append({"gene":gene,"n_PSC":len(groups[0]),"n_PBC":len(groups[1]),"n_MASLD":len(groups[2]),"kruskal_statistic":test.statistic,"p_value":test.pvalue})
    stage = pd.DataFrame(stage_rows); groups = pd.DataFrame(group_rows)
    if not stage.empty: stage["fdr_bh"] = multipletests(stage.p_value, method="fdr_bh")[1]
    if not groups.empty: groups["fdr_bh"] = multipletests(groups.p_value, method="fdr_bh")[1]
    mrtf, mrtf_genes = score(gene_expr.loc[:, psc], MRTF_PROXY)
    emt, emt_genes = score(gene_expr.loc[:, psc], EMT_PROXY)
    proxy_rows=[]
    for name, values in (("MRTF_SRF_proxy",mrtf),("EMT_proxy",emt)):
        for gene in ("ARPC2","MKL1","SRF","ACTA2","TAGLN","SNAI2"):
            if gene in gene_expr.index:
                valid=pd.concat([values.rename("score"),gene_expr.loc[gene,psc].rename("gene")],axis=1).dropna()
                if len(valid)>=4:
                    rho,p=spearmanr(valid.score,valid.gene); proxy_rows.append({"score":name,"gene":gene,"n":len(valid),"spearman_rho":rho,"p_value":p})
    proxy=pd.DataFrame(proxy_rows)
    if not proxy.empty: proxy["fdr_bh"]=multipletests(proxy.p_value,method="fdr_bh")[1]
    methods=pd.DataFrame([{"score":"MRTF_SRF_proxy","genes":";".join(mrtf_genes),"interpretation":"Exploratory downstream contractile/ECM proxy; not MRTF-A nuclear localization or direct SRF activity"},{"score":"EMT_proxy","genes":";".join(emt_genes),"interpretation":"Exploratory candidate expression proxy; sensitive to cell composition"}])
    with pd.ExcelWriter(OUT / "zenodo_psc_results.xlsx") as writer:
        clinical.reset_index().to_excel(writer,sheet_name="clinical_metadata",index=False)
        mapping.to_excel(writer,sheet_name="gene_mapping",index=False)
        stage.to_excel(writer,sheet_name="PSC_stage",index=False)
        groups.to_excel(writer,sheet_name="diagnosis_tests",index=False)
        proxy.to_excel(writer,sheet_name="proxy_correlations",index=False)
        methods.to_excel(writer,sheet_name="proxy_methods",index=False)
    # Primary PSC ARPC2 figure with real P value and independent patient points.
    valid=psc & clinical.fibrosis.notna() & gene_expr.loc["ARPC2"].notna()
    plot=pd.DataFrame({"fibrosis":clinical.loc[valid,"fibrosis"].astype(int),"ARPC2":gene_expr.loc["ARPC2",valid].to_numpy()})
    rho,p=spearmanr(plot.fibrosis,plot.ARPC2)
    fig,ax=plt.subplots(figsize=(5.1,4.3)); sns.regplot(data=plot,x="fibrosis",y="ARPC2",x_jitter=.08,scatter_kws={"s":35,"color":"#4C78A8"},line_kws={"color":"#E45756"},ci=95,ax=ax); ax.text(.98,.98,f"Spearman ρ={rho:.3f}\nP={p:.3g}; n={len(plot)}",transform=ax.transAxes,ha="right",va="top",fontsize=8); ax.set(xlabel="PSC fibrosis stage",ylabel="ARPC2 log2(CPM+1)",title="Zenodo 13990103: PSC cohort"); sns.despine(); save_figure(fig,ROOT/"results/figures/Figure_H_Zenodo_PSC_ARPC2_stage")
    stage.to_csv(OUT/"zenodo_psc_stage_association.csv",index=False); groups.to_csv(OUT/"zenodo_diagnosis_tests.csv",index=False); proxy.to_csv(OUT/"zenodo_proxy_correlations.csv",index=False); methods.to_csv(OUT/"zenodo_proxy_methods.csv",index=False)
    print("PSC samples:",int(psc.sum()),"PBC:",int(clinical.diagnosis.eq('PBC').sum()),"MASLD:",int(clinical.diagnosis.eq('MASLD').sum()))
    print(stage.to_string(index=False))

if __name__ == "__main__": main()
