#!/usr/bin/env python3
"""Create explicit sample/dataset QC tables from completed first-stage runs."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
rows, flags = [], []
for accession in ("GSE159676", "GSE84044"):
    base = ROOT / "data/processed" / accession
    meta = pd.read_csv(base / "sample_metadata_annotated.csv", index_col=0)
    expression_file = base / "gene_expression_sample.csv"
    if not expression_file.exists(): expression_file = base / "gene_expression.csv"
    expr = pd.read_csv(expression_file, index_col=0)
    platform = ",".join(sorted(meta["platform_id"].dropna().unique()))
    units = meta.get("independent_unit", meta.get("patient_id", meta.index))
    duplicates = meta.get("potential_duplicate", pd.Series(False, index=meta.index))
    row = {"dataset": accession, "platform": platform, "n_samples": len(meta), "n_unique_patients_or_units": units.nunique(), "n_potential_duplicate_samples": int(duplicates.sum())}
    if "analysis_group" in meta:
        row.update({f"n_{key}": int(value) for key, value in meta["analysis_group"].value_counts().items()})
    if "scheuer_stage" in meta:
        row.update({f"n_scheuer_stage_{int(key)}": int(value) for key, value in meta["scheuer_stage"].dropna().value_counts().items()})
    rows.append(row)
    if "ARPC2" in expr.index:
        for sample_id, value in expr.loc["ARPC2"].items():
            flags.append({"dataset": accession, "sample_id": sample_id, "ARPC2_value": value, "extreme_raw_value_flag": bool(value > 100)})
pd.DataFrame(rows).to_csv(ROOT / "results/tables/dataset_qc_summary.csv", index=False)
pd.DataFrame(flags).to_csv(ROOT / "results/tables/sample_qc_flags.csv", index=False)
print(pd.DataFrame(rows).to_string(index=False))
