#!/usr/bin/env python3
"""Marker-based, donor-aware analysis of human liver cells in GSE136103.

The GEO archive contains human liver, human blood/PBMC and mouse samples. This
script explicitly keeps only human healthy/cirrhotic liver libraries, labels
cells from canonical marker scores, and uses patient-level summaries for group
comparisons. UMAP is descriptive; inferential tests never treat cells as
independent patients.
"""
from __future__ import annotations
import gzip
import re
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy.io import mmread
from scipy.stats import mannwhitneyu
import scanpy as sc

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data/raw/GSE136103"
OUT = ROOT / "data/processed/GSE136103"
GENES = ["ARPC2", "KRT7", "KRT19", "EPCAM", "KRT8", "KRT18", "COL1A1", "COL3A1", "COL1A2", "DCN", "LUM", "RGS5", "PTPRC", "CD74", "HLA-DRA", "LST1", "ALB", "APOA1", "TTR", "KDR", "EMCN", "PECAM1", "VWF"]
MARKERS = {
    "Cholangiocyte": ["KRT7", "KRT19", "EPCAM", "KRT8", "KRT18"],
    "Hepatic_stellate": ["COL1A1", "COL3A1", "COL1A2", "DCN", "LUM", "RGS5"],
    "Immune": ["PTPRC", "CD74", "HLA-DRA", "LST1"],
    "Hepatocyte": ["ALB", "APOA1", "TTR"],
    "Endothelial": ["KDR", "EMCN", "PECAM1", "VWF"],
}
COLORS = {"Healthy": "#4C78A8", "Cirrhotic": "#E45756"}

def read_genes(path: Path) -> list[str]:
    with gzip.open(path, "rt", encoding="utf-8", errors="replace") as handle:
        table = pd.read_csv(handle, sep="\t", header=None)
    names = table.iloc[:, 1] if table.shape[1] > 1 else table.iloc[:, 0]
    return names.astype(str).tolist()

def load_library(prefix: Path) -> tuple[list[str], object]:
    gene_file = next(prefix.parent.glob(prefix.name + "_genes.tsv.gz"))
    matrix_file = next(prefix.parent.glob(prefix.name + "_matrix.mtx.gz"))
    genes = read_genes(gene_file)
    with gzip.open(matrix_file, "rb") as handle:
        matrix = mmread(handle).tocsr()
    return genes, matrix

def normalized_marker_data(genes: list[str], matrix, rng: np.random.Generator, sample_id: str, disease: str, patient: str):
    upper = pd.Series(genes).str.upper()
    positions = {}
    for gene in GENES:
        hits = np.flatnonzero(upper.to_numpy() == gene)
        if len(hits): positions[gene] = int(hits[0])
    if "ARPC2" not in positions: raise ValueError(f"{sample_id}: ARPC2 is absent from gene annotation")
    library = np.asarray(matrix.sum(axis=0)).ravel().astype(float)
    detected = np.asarray((matrix > 0).sum(axis=0)).ravel()
    keep = (library > 500) & (detected > 200)
    cells = np.flatnonzero(keep)
    if len(cells) > 600: cells = rng.choice(cells, 600, replace=False)
    matrix = matrix[:, cells]
    library = library[cells]
    normalized = matrix.multiply(10000 / library).log1p().tocsr()
    values = {gene: np.asarray(normalized.getrow(pos).todense()).ravel() for gene, pos in positions.items()}
    scores = {cell_type: np.mean([values[g] for g in marker_genes if g in values], axis=0) for cell_type, marker_genes in MARKERS.items()}
    score_table = pd.DataFrame(scores)
    assigned = score_table.idxmax(axis=1)
    assigned[score_table.max(axis=1) <= 0.05] = "Other"
    meta = pd.DataFrame({"sample_id": sample_id, "patient": patient, "disease": disease, "cell_type": assigned.to_numpy(), "ARPC2": values["ARPC2"], "library_size": library, "n_genes": detected[cells]})
    # Retain marker expression for dot plots and UMAP; columns absent from a library stay zero.
    marker_frame = pd.DataFrame({gene: values.get(gene, np.zeros(len(cells))) for gene in GENES})
    return meta, marker_frame

def save_figure(fig, stem: Path):
    for suffix, kwargs in (("pdf", {}), ("svg", {}), ("tiff", {"dpi": 600}), ("png", {"dpi": 300})):
        fig.savefig(stem.with_suffix("." + suffix), bbox_inches="tight", **kwargs)

def main():
    rng = np.random.default_rng(2026)
    records, marker_frames, library_records = [], [], []
    files = sorted(RAW.glob("GSM*_*.mtx.gz"))
    for matrix_file in files:
        name = matrix_file.name.removesuffix("_matrix.mtx.gz")
        lower = name.lower()
        if "mouse" in lower or "blood" in lower or not re.search(r"_(healthy|cirrhotic)\d+_", lower):
            continue
        match = re.search(r"_(healthy|cirrhotic)(\d+)_", lower)
        disease = "Healthy" if match.group(1) == "healthy" else "Cirrhotic"
        patient = f"{match.group(1)}{match.group(2)}"
        prefix = matrix_file.with_name(name)
        genes, matrix = load_library(prefix)
        meta, marker_frame = normalized_marker_data(genes, matrix, rng, name.split("_")[0], disease, patient)
        records.append(meta)
        marker_frames.append(marker_frame)
        library_records.append({"sample_id": name.split("_")[0], "library_name": name, "disease": disease, "patient": patient, "n_cells_after_qc": len(meta), "n_genes": len(genes), "matrix_cells": matrix.shape[1]})
    if not records: raise RuntimeError("No human liver libraries found in extracted GSE136103 archive")
    cell_table = pd.concat(records, ignore_index=True)
    marker_table = pd.concat(marker_frames, ignore_index=True)
    OUT.mkdir(parents=True, exist_ok=True)
    cell_table.to_csv(OUT / "human_liver_cell_metadata.csv", index=False)
    pd.DataFrame(library_records).to_csv(OUT / "library_qc.csv", index=False)
    pseudobulk = cell_table.assign(**{gene: marker_table[gene].to_numpy() for gene in GENES}).groupby(["patient", "disease", "cell_type"], as_index=False).agg(ARPC2_mean=("ARPC2", "mean"), ARPC2_fraction_detected=("ARPC2", lambda x: float(np.mean(x > 0))), n_cells=("ARPC2", "size"))
    pseudobulk.to_csv(ROOT / "results/tables/GSE136103_ARPC2_pseudobulk.csv", index=False)
    inferential = []
    for cell_type, group in pseudobulk.groupby("cell_type"):
        healthy = group.loc[group.disease == "Healthy", "ARPC2_mean"]
        cirrhotic = group.loc[group.disease == "Cirrhotic", "ARPC2_mean"]
        if len(healthy) >= 2 and len(cirrhotic) >= 2:
            test = mannwhitneyu(healthy, cirrhotic, alternative="two-sided", method="asymptotic")
            inferential.append({"cell_type": cell_type, "n_healthy_patients": len(healthy), "n_cirrhotic_patients": len(cirrhotic), "healthy_median": healthy.median(), "cirrhotic_median": cirrhotic.median(), "median_difference_cirrhotic_minus_healthy": cirrhotic.median() - healthy.median(), "mann_whitney_U": test.statistic, "p_value": test.pvalue})
        else:
            inferential.append({"cell_type": cell_type, "n_healthy_patients": len(healthy), "n_cirrhotic_patients": len(cirrhotic), "reason": "fewer than two patients per disease group"})
    stats = pd.DataFrame(inferential)
    stats.to_csv(ROOT / "results/tables/GSE136103_ARPC2_patient_level_statistics.csv", index=False)
    with pd.ExcelWriter(ROOT / "results/tables/GSE136103_statistics.xlsx") as writer:
        stats.to_excel(writer, sheet_name="patient_level", index=False)
        pseudobulk.to_excel(writer, sheet_name="pseudobulk", index=False)
        pd.DataFrame(library_records).to_excel(writer, sheet_name="library_qc", index=False)
    # Use Scanpy for the dimensionality reduction/neighbor graph, while keeping
    # patient-level summaries for every disease comparison above.
    embedding_genes = [g for g in GENES if g in marker_table]
    adata = sc.AnnData(X=marker_table[embedding_genes].to_numpy(dtype=np.float32).copy(), obs=cell_table.copy(), var=pd.DataFrame(index=embedding_genes))
    sc.pp.scale(adata, max_value=10)
    sc.tl.pca(adata, n_comps=min(15, len(embedding_genes) - 1), random_state=2026)
    sc.pp.neighbors(adata, n_neighbors=20, n_pcs=min(15, len(embedding_genes) - 1), metric="cosine", random_state=2026)
    sc.tl.umap(adata, min_dist=0.3, random_state=2026)
    embedding = adata.obsm["X_umap"]
    cell_table["UMAP1"], cell_table["UMAP2"] = embedding[:, 0], embedding[:, 1]
    cell_table.to_csv(OUT / "human_liver_cell_metadata_with_umap.csv", index=False)
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.2), gridspec_kw={"width_ratios": [1, 1, 1.15]})
    scatter = axes[0].scatter(embedding[:, 0], embedding[:, 1], c=cell_table["ARPC2"], s=2, cmap="viridis", rasterized=True)
    fig.colorbar(scatter, ax=axes[0], label="ARPC2 log1p(CP10K)")
    sns.scatterplot(data=cell_table, x="UMAP1", y="UMAP2", hue="cell_type", s=3, linewidth=0, legend=False, ax=axes[1], palette="tab10")
    axes[0].set_title("ARPC2 FeaturePlot"); axes[1].set_title("Marker-based cell types")
    dot = cell_table.assign(**{gene: marker_table[gene].to_numpy() for gene in ["ARPC2", "KRT7", "KRT19", "COL1A1", "COL3A1", "DCN", "LUM"]}).groupby("cell_type")[["ARPC2", "KRT7", "KRT19", "COL1A1", "COL3A1", "DCN", "LUM"]].mean()
    sns.heatmap(dot.T, cmap="viridis", ax=axes[2], cbar_kws={"label": "mean log1p(CP10K)"})
    axes[2].set_title("Marker DotPlot (mean expression)")
    chol_p = stats.loc[stats["cell_type"].eq("Cholangiocyte"), "p_value"].iloc[0]
    hsc_p = stats.loc[stats["cell_type"].eq("Hepatic_stellate"), "p_value"].iloc[0]
    fig.text(0.5, 0.01, f"Patient-level Mann–Whitney: cholangiocyte P={chol_p:.3g}; hepatic stellate P={hsc_p:.3g}", ha="center", fontsize=8)
    for ax in axes[:2]: ax.set_xlabel("UMAP1"); ax.set_ylabel("UMAP2")
    sns.despine()
    save_figure(fig, ROOT / "results/figures/Figure_D_GSE136103_ARPC2_UMAP_DotPlot")
    plt.close(fig)
    print(stats.to_string(index=False))

if __name__ == "__main__":
    main()
