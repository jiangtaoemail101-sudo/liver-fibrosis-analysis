#!/usr/bin/env python3
"""Download official GEO series matrix and family SOFT files with provenance."""
from __future__ import annotations
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
GROUPS = {"GSE159676": "GSE159nnn", "GSE84044": "GSE84nnn", "GSE239283": "GSE239nnn", "GSE136103": "GSE136nnn", "GSE247128": "GSE247nnn"}

def url_for(accession: str, filename: str) -> str:
    subdirectory = "matrix/" if filename.endswith("_series_matrix.txt.gz") else "soft/"
    return f"https://ftp.ncbi.nlm.nih.gov/geo/series/{GROUPS[accession]}/{accession}/{subdirectory}{filename}"

def download(url: str, destination: Path) -> dict:
    destination.parent.mkdir(parents=True, exist_ok=True)
    request = Request(url, headers={"User-Agent": "ARPC2-GEO-reproducible-analysis/1.0"})
    started = time.time()
    with urlopen(request, timeout=60) as response, destination.open("wb") as handle:
        while block := response.read(1024 * 1024):
            handle.write(block)
    return {"url": url, "path": str(destination.relative_to(ROOT)), "bytes": destination.stat().st_size,
            "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
            "downloaded_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "seconds": round(time.time() - started, 2)}

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--accession", action="append", choices=sorted(GROUPS))
    args = parser.parse_args()
    accessions = args.accession or ["GSE159676", "GSE84044"]
    manifest_path = RAW / "download_manifest.json"
    previous = {}
    if manifest_path.exists():
        try:
            previous = {item["accession"]: item for item in json.loads(manifest_path.read_text()).get("datasets", [])}
        except (ValueError, KeyError):
            previous = {}
    manifest = {"source": "NCBI GEO FTP", "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "datasets": []}
    selected_results = []
    for accession in accessions:
        result = {"accession": accession, "files": [], "errors": []}
        for filename in (f"{accession}_series_matrix.txt.gz", f"{accession}_family.soft.gz"):
            url = url_for(accession, filename)
            try:
                print(f"Downloading {url}", flush=True)
                result["files"].append(download(url, RAW / accession / filename))
            except (HTTPError, URLError, TimeoutError, OSError) as exc:
                result["errors"].append({"url": url, "error": repr(exc)})
        previous[accession] = result
        selected_results.append(result)
    manifest["datasets"] = [previous[accession] for accession in sorted(previous)]
    manifest["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(f"Wrote {manifest_path}")
    if any(item["errors"] for item in selected_results):
        print("Official GEO download failed; see download_manifest.json.", file=sys.stderr)
        return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
