#!/usr/bin/env python3
"""Render reports from the result tables; no numbers are entered by hand."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
g159 = pd.read_csv(ROOT / "results/tables/GSE159676_ARPC2_statistics.csv")
g159_groups = g159[g159.group.notna()].set_index("group")
g159_kw = g159[g159.test == "Kruskal-Wallis"].iloc[0]
g840 = pd.read_csv(ROOT / "results/tables/GSE84044_ARPC2_stage_correlation.csv").iloc[0]
g840_corr = pd.read_csv(ROOT / "results/tables/GSE84044_fibrosis_gene_correlations.csv").set_index("gene")
g239 = pd.read_csv(ROOT / "results/tables/GSE239283_organoid_ARPC2_statistics.csv").iloc[0]
g136 = pd.read_csv(ROOT / "results/tables/GSE136103_ARPC2_patient_level_statistics.csv").set_index("cell_type")

zh = f"""# ARPC2 公共转录组分析报告

所有数字均来自 `results/tables/` 的真实 GEO 分析输出，未使用模拟数据。

## 数据集核对

- GSE159676（GPL6244）共 33 个样本：健康 6、PSC 12、PBC 3，另有其他肝病 12。PSC 样本为 `PSC_1_a`–`PSC_6_a` 与 `PSC_1_b`–`PSC_6_b`，主比较按 6 个独立 PSC 供体对成对样本取中位数；其他肝病未纳入三组比较。
- GSE84044（GPL570）共 124 个慢性乙肝患者肝组织样本，Scheuer S0/S1/S2/S3/S4 为 43/20/33/18/10。它不是胆汁淤积性肝病队列，可用于纤维化分期关联而不能证明 PSC/PBC 特异性。
- GSE239283（GPL20301）为 10x 胆管类器官，16 个样本（8 CNT/Vehicle、8 IL17）。Vehicle 主比较使用 PSC 4 个供体与 nonPSC 4 个供体，统计单位为供体。
- GSE136103 RAW tar 同时含人肝、人血/PBMC 和小鼠。分析仅保留 5 个健康人与 5 个肝硬化患者的 20 个人肝文库，排除血液和小鼠；Scanpy UMAP 使用 11,835 个质量控制后抽样细胞，疾病检验按患者伪 bulk 汇总。
- 未使用 GSE61260，因为其 GEO 登记不符合本研究指定的 PBC/PSC 目的。

## 主要结果

### GSE159676

ARPC2 独立供体中位表达：健康 n={int(g159_groups.loc['control','n'])}、{g159_groups.loc['control','median']:.4f}；PBC n={int(g159_groups.loc['pbc','n'])}、{g159_groups.loc['pbc','median']:.4f}；PSC n={int(g159_groups.loc['psc','n'])}、{g159_groups.loc['psc','median']:.4f}。Kruskal–Wallis H={g159_kw.statistic:.4f}，P={g159_kw.p_value:.4g}，三组未见显著差异。健康样本 GSM4837495 的 ARPC2 原始值为 2,640,552，而其余值约为 9–10；该值被保留并记录为 QC 异常，未为追求显著性而删除。

### GSE84044

ARPC2 与 Scheuer 分期正相关（n={int(g840.n)}，rho={g840.spearman_rho:.4f}，P={g840.p_value:.4g}）。COL3A1（rho={g840_corr.loc['COL3A1','spearman_rho']:.4f}，FDR={g840_corr.loc['COL3A1','fdr_bh']:.4g}）、KRT19（rho={g840_corr.loc['KRT19','spearman_rho']:.4f}，FDR={g840_corr.loc['KRT19','fdr_bh']:.4g}）和 COL1A1（rho={g840_corr.loc['COL1A1','spearman_rho']:.4f}，FDR={g840_corr.loc['COL1A1','fdr_bh']:.4g}）与分期相关；ACTA2、FN1、KRT7、MKL1、SRF 未显著相关。

### GSE239283

Vehicle/CNT 供体级 ARPC2 mean log1p(CP10K) 为 PSC 中位 {g239.PSC_median:.4f}（n=4）与 nonPSC 中位 {g239.nonPSC_median:.4f}（n=4），Mann–Whitney P={g239.p_value:.4f}，未见显著差异。IL17 样本没有混入该 Vehicle 主比较。

### GSE136103

Scanpy 标志基因注释识别了胆管上皮、肝星状、内皮、肝细胞和免疫群。患者级 ARPC2 比较未显著：胆管上皮健康/肝硬化中位 {g136.loc['Cholangiocyte','healthy_median']:.4f}/{g136.loc['Cholangiocyte','cirrhotic_median']:.4f}，P={g136.loc['Cholangiocyte','p_value']:.4f}；肝星状细胞 {g136.loc['Hepatic_stellate','healthy_median']:.4f}/{g136.loc['Hepatic_stellate','cirrhotic_median']:.4f}，P={g136.loc['Hepatic_stellate','p_value']:.4f}。

## 论文定位与边界

Figure B/C 最适合主文，Figure A 可作为 PSC/PBC/健康背景但应说明阴性总体检验和 QC 异常，Figure D 用于细胞定位，Figure E 更适合支持性材料。数据支持 ARPC2 与人肝纤维化分期相关，并可定位于胆管、肝星状及其他肝细胞群；不能单独证明 AA 直接靶向 ARPC2、不能证明 PSC/PBC 特异性因果机制，也不能替代动物、TPP/PELSA 和功能实验。
"""

en = f"""## Results draft

GSE159676 (GPL6244) contained 33 GEO samples: 6 healthy livers, 12 PSC samples representing six paired a/b specimens, 3 PBC samples and 12 samples from other liver diseases. Paired PSC specimens were summarized within donor. ARPC2 expression did not differ among healthy (n={int(g159_groups.loc['control','n'])}), PBC (n={int(g159_groups.loc['pbc','n'])}) and PSC (n={int(g159_groups.loc['psc','n'])}) donors by Kruskal–Wallis testing (H={g159_kw.statistic:.4f}, P={g159_kw.p_value:.4g}). One extreme raw value was retained and documented in the QC table.

In GSE84044, a chronic hepatitis B rather than cholestatic liver cohort, ARPC2 was positively associated with Scheuer fibrosis stage (n={int(g840.n)}, Spearman rho={g840.spearman_rho:.4f}, P={g840.p_value:.4g}). COL3A1, KRT19 and COL1A1 remained associated after Benjamini–Hochberg adjustment, whereas ACTA2, FN1, KRT7, MKL1 and SRF did not.

In the GSE239283 vehicle/CNT organoid samples, donor-level ARPC2 did not differ between PSC and non-PSC organoids (n=4 per group; medians {g239.PSC_median:.4f} and {g239.nonPSC_median:.4f}; Mann–Whitney P={g239.p_value:.4f}). In GSE136103, Scanpy marker annotation identified cholangiocyte and hepatic stellate populations in human liver libraries. Patient-level ARPC2 comparisons were not significant in cholangiocytes (P={g136.loc['Cholangiocyte','p_value']:.4f}) or hepatic stellate cells (P={g136.loc['Hepatic_stellate','p_value']:.4f}).

## Figure legends

**Figure A. ARPC2 expression in healthy, PBC and PSC human liver (GSE159676).** Boxes show donor-level expression and points show independent donors; paired PSC a/b specimens were summarized within donor. Overall Kruskal–Wallis H={g159_kw.statistic:.4f}, P={g159_kw.p_value:.4g}. The extreme raw value in GSM4837495 was retained and documented.

**Figure B. ARPC2 across Scheuer fibrosis stages in chronic hepatitis B liver (GSE84044).** Points are individual liver samples; Spearman rho={g840.spearman_rho:.4f}, n={int(g840.n)}, P={g840.p_value:.4g}. This is not a PSC/PBC cohort.

**Figure C. Stage correlations of ARPC2 and fibrosis/cholangiocyte genes.** Heatmap colors represent Spearman coefficients for ARPC2, ACTA2, COL1A1, COL3A1, FN1, KRT7, KRT19, MKL1 and SRF; FDR uses Benjamini–Hochberg correction.

**Figure D. ARPC2 in human liver single-cell RNA-seq (GSE136103).** Scanpy UMAP and marker heatmap show human liver cells after library QC and capped sampling for visualization. Blood/PBMC and mouse samples were excluded; disease comparisons used patient-level pseudobulk summaries.

**Figure E. ARPC2 in vehicle/CNT bile duct organoids (GSE239283).** Each point is one donor (four PSC and four non-PSC donors); donor-level Mann–Whitney P={g239.p_value:.4f}.
"""
(ROOT / "reports/analysis_report_zh.md").write_text(zh)
(ROOT / "reports/results_and_figure_legends_en.md").write_text(en)
# Append the Zenodo PSC cohort section when that stage has been downloaded.
zenodo_stage = ROOT / "results/tables/zenodo_psc_stage_association.csv"
if zenodo_stage.exists():
    z = pd.read_csv(zenodo_stage).set_index("gene")
    psc = z.loc["ARPC2"]
    section_zh = f"""\n\n## Zenodo PSC 纤维化分期队列\n\nZenodo 13990103 包含 PSC 16、PBC 15 和 MASLD 16 个样本；没有健康对照，因此未进行健康组比较。PSC 内 ARPC2 与纤维化分期的 Spearman ρ={psc.spearman_rho:.4f}，P={psc.p_value:.4g}，FDR={psc.fdr_bh:.4g}。该结果不支持 ARPC2 在此 PSC 队列中与分期存在显著单调关系。MRTF/SRF proxy、SNAI2 和候选基因结果见 `results/tables/zenodo_psc_results.xlsx`；proxy 是表达代理指标，不是 MRTF-A 核转位或直接 SRF 结合测量。\n\nGSE247128 已完成 GEO 元数据筛选：包含 PBC/PSC 单细胞/单核文库，但无空间文件、无健康对照和无分期字段，因此未纳入定量主分析。\n"""
    section_en = f"""\n\n## Zenodo PSC fibrosis cohort\n\nZenodo 13990103 contained PSC (n=16), PBC (n=15) and MASLD (n=16) samples without a healthy control. Within PSC, ARPC2 was not associated with fibrosis stage (Spearman rho={psc.spearman_rho:.4f}, P={psc.p_value:.4g}, FDR={psc.fdr_bh:.4g}). The MRTF/SRF proxy and SNAI2 results are in `results/tables/zenodo_psc_results.xlsx`; the proxy is an expression summary and not a measurement of MRTF-A nuclear localization or direct SRF binding. GSE247128 was screened as PBC/PSC single-cell/single-nucleus data, but no spatial files, healthy controls or fibrosis-stage field were available, so it was not included in quantitative inference.\n"""
    for path, section in ((ROOT / "reports/analysis_report_zh.md", section_zh), (ROOT / "reports/results_and_figure_legends_en.md", section_en)):
        old = path.read_text()
        marker = "\n## Zenodo PSC"
        old = old.split(marker, 1)[0]
        path.write_text(old + section)
print("Wrote reports from result tables")
