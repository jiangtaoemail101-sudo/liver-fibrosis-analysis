#!/usr/bin/env python3
"""Candidate-gene, proxy-program and patient-level association analyses.

The MRTF/SRF score below is deliberately labelled a proxy: it is a
prespecified downstream contractile/ECM candidate set, not a measurement of
MRTF-A nuclear localization or direct SRF binding.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import kruskal, mannwhitneyu, spearmanr
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parents[1]
CORE = ["ARPC2", "MKL1", "SRF", "ACTA2", "TAGLN", "COL1A1", "COL3A1", "FN1", "KRT19", "KRT7", "SNAI2"]
FIBROSIS = ["ARPC2", "ACTA2", "TAGLN", "COL1A1", "COL1A2", "COL3A1", "FN1", "CCN2", "TIMP1", "LOX", "PDGFRB"]
DUCTAL = ["KRT19", "KRT7", "SOX9", "EPCAM", "SPP1", "MUC1"]
EMT = ["SNAI2", "SNAI1", "ZEB1", "ZEB2", "TWIST1", "CDH1", "CDH2", "VIM", "TJP1", "FN1"]
MRTF_PROXY = ["ACTA2", "TAGLN", "CNN1", "MYL9", "TPM2", "CALD1", "COL1A1", "COL3A1", "CCN2", "FN1"]

def zscore(frame: pd.DataFrame) -> pd.DataFrame:
    return frame.apply(lambda x: (x - x.mean()) / x.std(ddof=1) if x.std(ddof=1) > 0 else x * 0, axis=1)

def score(frame: pd.DataFrame, genes: list[str]) -> tuple[pd.Series, list[str]]:
    available = [gene for gene in genes if gene in frame.index and frame.loc[gene].notna().sum() >= 3]
    if not available: return pd.Series(np.nan, index=frame.columns), []
    return zscore(frame.loc[available]).mean(axis=0), available

def spearman_table(frame: pd.DataFrame, genes: list[str], label: str) -> pd.DataFrame:
    rows = []
    available = [gene for gene in genes if gene in frame.index]
    for i, left in enumerate(available):
        for right in available[i + 1:]:
            valid = frame.loc[[left, right]].dropna(axis=1).T
            if len(valid) >= 4:
                rho, p = spearmanr(valid[left], valid[right])
                rows.append({"dataset": label, "gene_1": left, "gene_2": right, "n": len(valid), "spearman_rho": rho, "p_value": p})
    out = pd.DataFrame(rows)
    if not out.empty: out["fdr_bh"] = multipletests(out.p_value, method="fdr_bh")[1]
    return out

def write_figure(frame: pd.DataFrame, x: str, y: str, output: Path, title: str):
    valid = frame[[x, y]].dropna()
    rho, p = spearmanr(valid[x], valid[y]) if len(valid) >= 4 else (np.nan, np.nan)
    fig, ax = plt.subplots(figsize=(4.6, 4.2))
    sns.regplot(data=valid, x=x, y=y, scatter_kws={"s": 28, "color": "#4C78A8"}, line_kws={"color": "#E45756"}, ci=95, ax=ax)
    ax.text(.98, .98, f"Spearman ρ={rho:.3f}\nP={p:.3g}; n={len(valid)}", transform=ax.transAxes, ha="right", va="top", fontsize=8)
    ax.set_title(title); sns.despine()
    for suffix, kwargs in (("pdf", {}), ("svg", {}), ("tiff", {"dpi": 600}), ("png", {"dpi": 300})):
        fig.savefig(output.with_suffix("." + suffix), bbox_inches="tight", **kwargs)
    plt.close(fig)

def main():
    g159 = pd.read_csv(ROOT / "data/processed/GSE159676/gene_expression.csv", index_col=0)
    m159 = pd.read_csv(ROOT / "data/processed/GSE159676/sample_metadata_annotated.csv", index_col=0)
    groups = m159.groupby("independent_unit")["analysis_group"].first().reindex(g159.columns)
    candidate = sorted(set(CORE + FIBROSIS + DUCTAL + EMT))
    summaries, tests = [], []
    for gene in candidate:
        if gene not in g159.index: continue
        for group in ("control", "pbc", "psc"):
            values = g159.loc[gene, groups.eq(group)].dropna()
            summaries.append({"dataset": "GSE159676", "gene": gene, "group": group, "unit": "independent_donor", "n": len(values), "median": values.median(), "mean": values.mean()})
        available = [g159.loc[gene, groups.eq(group)].dropna() for group in ("control", "pbc", "psc")]
        if all(len(x) >= 2 for x in available):
            test = kruskal(*available)
            tests.append({"dataset": "GSE159676", "gene": gene, "test": "Kruskal-Wallis", "n_total": sum(map(len, available)), "statistic": test.statistic, "p_value": test.pvalue})
    tests159 = pd.DataFrame(tests)
    if not tests159.empty: tests159["fdr_bh"] = multipletests(tests159.p_value, method="fdr_bh")[1]
    g840 = pd.read_csv(ROOT / "data/processed/GSE84044/gene_expression.csv", index_col=0)
    m840 = pd.read_csv(ROOT / "data/processed/GSE84044/sample_metadata_annotated.csv", index_col=0)
    stage = m840.scheuer_stage.to_numpy()
    stage_rows = []
    for gene in candidate:
        if gene not in g840.index: continue
        valid = np.isfinite(stage) & g840.loc[gene].notna().to_numpy()
        if valid.sum() >= 4 and len(np.unique(stage[valid])) >= 2:
            rho, p = spearmanr(stage[valid], g840.loc[gene].to_numpy()[valid])
            stage_rows.append({"dataset": "GSE84044", "gene": gene, "n": int(valid.sum()), "spearman_rho": rho, "p_value": p})
    stage_table = pd.DataFrame(stage_rows)
    if not stage_table.empty: stage_table["fdr_bh"] = multipletests(stage_table.p_value, method="fdr_bh")[1]
    assoc840 = spearman_table(g840, CORE, "GSE84044")
    assoc159 = spearman_table(g159, CORE, "GSE159676 independent donors")
    mrtf840, mrtf_genes = score(g840, MRTF_PROXY)
    emt840, emt_genes = score(g840, EMT)
    mrtf159, _ = score(g159, MRTF_PROXY)
    emt159, _ = score(g159, EMT)
    score_rows = []
    for name, values, frame, label in (("MRTF_SRF_proxy", mrtf840, g840, "GSE84044"), ("EMT_proxy", emt840, g840, "GSE84044"), ("MRTF_SRF_proxy", mrtf159, g159, "GSE159676"), ("EMT_proxy", emt159, g159, "GSE159676")):
        for gene in ["ARPC2", "MKL1", "SRF", "ACTA2", "TAGLN", "SNAI2"]:
            if gene not in frame.index: continue
            valid = pd.concat([values.rename("score"), frame.loc[gene].rename("gene")], axis=1).dropna()
            if len(valid) >= 4:
                rho, p = spearmanr(valid.score, valid.gene)
                score_rows.append({"dataset": label, "score": name, "gene": gene, "n": len(valid), "spearman_rho": rho, "p_value": p})
    score_table = pd.DataFrame(score_rows)
    if not score_table.empty: score_table["fdr_bh"] = multipletests(score_table.p_value, method="fdr_bh")[1]
    methods = pd.DataFrame([
        {"score": "MRTF_SRF_proxy", "genes": ";".join(mrtf_genes), "evidence": "Exploratory downstream contractile/ECM proxy; not direct MRTF-A activity or nuclear localization", "algorithm": "gene-wise z-score across patients, then mean"},
        {"score": "EMT_proxy", "genes": ";".join(emt_genes), "evidence": "Exploratory epithelial/mesenchymal candidate expression proxy; sensitive to cell composition", "algorithm": "gene-wise z-score across patients, then mean"},
    ])
    out = ROOT / "results/tables"
    with pd.ExcelWriter(out / "clinical_expression_results.xlsx") as writer:
        pd.DataFrame(summaries).to_excel(writer, sheet_name="GSE159676_groups", index=False)
        tests159.to_excel(writer, sheet_name="GSE159676_tests", index=False)
    with pd.ExcelWriter(out / "fibrosis_stage_association.xlsx") as writer:
        stage_table.to_excel(writer, sheet_name="GSE84044_stage", index=False)
        pd.read_csv(out / "GSE84044_ARPC2_stage_correlation.csv").to_excel(writer, sheet_name="ARPC2_primary", index=False)
    with pd.ExcelWriter(out / "ARPC2_MKL1_SRF_association.xlsx") as writer:
        assoc840.to_excel(writer, sheet_name="GSE84044_patient_correlations", index=False)
        assoc159.to_excel(writer, sheet_name="GSE159676_donor_correlations", index=False)
        score_table.to_excel(writer, sheet_name="program_score_correlations", index=False)
    with pd.ExcelWriter(out / "SNAI2_EMT_analysis.xlsx") as writer:
        stage_table[stage_table.gene.isin(EMT)].to_excel(writer, sheet_name="GSE84044_EMT_stage", index=False)
        assoc840[assoc840.gene_1.eq("SNAI2") | assoc840.gene_2.eq("SNAI2")].to_excel(writer, sheet_name="SNAI2_correlations", index=False)
        score_table[score_table.score.eq("EMT_proxy")].to_excel(writer, sheet_name="EMT_proxy", index=False)
    with pd.ExcelWriter(out / "MRTFA_SRF_activity_results.xlsx") as writer:
        methods.to_excel(writer, sheet_name="gene_set_methods", index=False)
        score_table[score_table.score.eq("MRTF_SRF_proxy")].to_excel(writer, sheet_name="proxy_correlations", index=False)
        stage_table[stage_table.gene.isin(MRTF_PROXY)].to_excel(writer, sheet_name="component_stage_tests", index=False)
    fig_dir = ROOT / "results/figures"
    write_figure(pd.DataFrame({"ARPC2": g840.loc["ARPC2"], "MRTF_SRF_proxy": mrtf840}), "ARPC2", "MRTF_SRF_proxy", fig_dir / "Figure_F_GSE84044_ARPC2_MRTF_proxy", "ARPC2 and MRTF/SRF proxy")
    write_figure(pd.DataFrame({"MKL1": g840.loc["MKL1"], "SNAI2": g840.loc["SNAI2"]}), "MKL1", "SNAI2", fig_dir / "Figure_G_GSE84044_MKL1_SNAI2", "MKL1 and SNAI2")
    methods.to_csv(out / "program_score_methods.csv", index=False)
    print("GSE159676 candidate tests:", len(tests159), "GSE84044 stage tests:", len(stage_table), "proxy genes:", mrtf_genes)

if __name__ == "__main__": main()
