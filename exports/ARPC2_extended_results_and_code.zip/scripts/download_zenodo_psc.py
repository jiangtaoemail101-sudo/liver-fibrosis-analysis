#!/usr/bin/env python3
"""Download the official files from Zenodo record 13990103 with provenance."""
from __future__ import annotations
import hashlib
import json
import sys
import time
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data/raw/zenodo_13990103"
API = "https://zenodo.org/api/records/13990103"

def main():
    request = Request(API, headers={"User-Agent": "ARPC2-PSC-reproducible-analysis/1.0"})
    try:
        with urlopen(request, timeout=60) as response:
            record = json.load(response)
    except Exception as exc:
        print(f"Zenodo record unavailable: {exc!r}. The environment must allow zenodo.org before this step can run.", file=sys.stderr)
        return 2
    RAW.mkdir(parents=True, exist_ok=True)
    selected = []
    for item in record.get("files", []):
        name = item.get("key", "")
        lower = name.lower()
        if any(token in lower for token in ("count", "clinical", "metadata", "sample", "gene_annotation", "gene_annotation")) and lower.endswith((".tsv", ".tsv.gz", ".csv", ".csv.gz", ".txt", ".txt.gz")):
            selected.append(item)
    if not selected:
        print("No count/clinical tabular files were identified; see record metadata in zenodo_record.json.", file=sys.stderr)
    manifest = {"record_url": "https://zenodo.org/records/13990103", "record_id": 13990103, "retrieved_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "files": []}
    (RAW / "zenodo_record.json").write_text(json.dumps(record, indent=2) + "\n")
    for item in selected:
        name = item["key"]
        url = item.get("links", {}).get("self") or item.get("links", {}).get("content")
        if not url: continue
        destination = RAW / Path(name).name
        req = Request(url, headers={"User-Agent": "ARPC2-PSC-reproducible-analysis/1.0"})
        print(f"Downloading {name}", flush=True)
        with urlopen(req, timeout=120) as source, destination.open("wb") as target:
            while block := source.read(1024 * 1024): target.write(block)
        manifest["files"].append({"name": name, "url": url, "path": str(destination.relative_to(ROOT)), "bytes": destination.stat().st_size, "sha256": hashlib.sha256(destination.read_bytes()).hexdigest()})
    (RAW / "download_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"Wrote {RAW / 'download_manifest.json'}")
    return 0

if __name__ == "__main__": raise SystemExit(main())
