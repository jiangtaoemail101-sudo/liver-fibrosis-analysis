#!/usr/bin/env bash
set -euo pipefail
cd /workspace/liver-fibrosis-analysis
source /workspace/.cloud-onboarding/liver-fibrosis-analysis/activate.sh
python scripts/download_geo.py --accession GSE159676 --accession GSE84044
python scripts/parse_geo.py GSE159676
python scripts/parse_geo.py GSE84044
