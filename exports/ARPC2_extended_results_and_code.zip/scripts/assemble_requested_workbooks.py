#!/usr/bin/env python3
"""Assemble the named deliverable workbooks from generated result tables."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "results/tables"

def main():
    with pd.ExcelWriter(TABLES / "fibrosis_stage_association.xlsx") as writer:
        pd.read_excel(TABLES / "GSE84044_statistics.xlsx", sheet_name="ARPC2_stage").to_excel(writer, sheet_name="GSE84044_stage", index=False)
        pd.read_excel(TABLES / "GSE84044_statistics.xlsx", sheet_name="gene_correlations").to_excel(writer, sheet_name="GSE84044_genes", index=False)
        pd.read_csv(TABLES / "zenodo_psc_stage_association.csv").to_excel(writer, sheet_name="Zenodo_PSC_stage", index=False)
    with pd.ExcelWriter(TABLES / "single_cell_results.xlsx") as writer:
        source = TABLES / "GSE136103_statistics.xlsx"
        pd.read_excel(source, sheet_name="patient_level").to_excel(writer, sheet_name="GSE136103_patient_level", index=False)
        pd.read_excel(source, sheet_name="pseudobulk").to_excel(writer, sheet_name="GSE136103_pseudobulk", index=False)
        pd.read_excel(source, sheet_name="library_qc").to_excel(writer, sheet_name="GSE136103_library_qc", index=False)
        pd.read_csv(ROOT / "data/processed/GSE247128/sample_metadata.csv").to_excel(writer, sheet_name="GSE247128_metadata", index=False)
    print("Assembled requested workbooks")

if __name__ == "__main__": main()
