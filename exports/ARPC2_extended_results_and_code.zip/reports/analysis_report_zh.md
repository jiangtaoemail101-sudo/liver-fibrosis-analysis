# ARPC2 公共转录组分析报告

所有数字均来自 `results/tables/` 的真实 GEO 分析输出，未使用模拟数据。

## 数据集核对

- GSE159676（GPL6244）共 33 个样本：健康 6、PSC 12、PBC 3，另有其他肝病 12。PSC 样本为 `PSC_1_a`–`PSC_6_a` 与 `PSC_1_b`–`PSC_6_b`，主比较按 6 个独立 PSC 供体对成对样本取中位数；其他肝病未纳入三组比较。
- GSE84044（GPL570）共 124 个慢性乙肝患者肝组织样本，Scheuer S0/S1/S2/S3/S4 为 43/20/33/18/10。它不是胆汁淤积性肝病队列，可用于纤维化分期关联而不能证明 PSC/PBC 特异性。
- GSE239283（GPL20301）为 10x 胆管类器官，16 个样本（8 CNT/Vehicle、8 IL17）。Vehicle 主比较使用 PSC 4 个供体与 nonPSC 4 个供体，统计单位为供体。
- GSE136103 RAW tar 同时含人肝、人血/PBMC 和小鼠。分析仅保留 5 个健康人与 5 个肝硬化患者的 20 个人肝文库，排除血液和小鼠；Scanpy UMAP 使用 11,835 个质量控制后抽样细胞，疾病检验按患者伪 bulk 汇总。
- 未使用 GSE61260，因为其 GEO 登记不符合本研究指定的 PBC/PSC 目的。

## 主要结果

### GSE159676

ARPC2 独立供体中位表达：健康 n=6、9.3373；PBC n=3、9.3842；PSC n=6、9.5060。Kruskal–Wallis H=0.5250，P=0.7691，三组未见显著差异。健康样本 GSM4837495 的 ARPC2 原始值为 2,640,552，而其余值约为 9–10；该值被保留并记录为 QC 异常，未为追求显著性而删除。

### GSE84044

ARPC2 与 Scheuer 分期正相关（n=124，rho=0.4397，P=3.24e-07）。COL3A1（rho=0.6053，FDR=8.371e-13）、KRT19（rho=0.5475，FDR=2.733e-10）和 COL1A1（rho=0.3271，FDR=0.0003856）与分期相关；ACTA2、FN1、KRT7、MKL1、SRF 未显著相关。

### GSE239283

Vehicle/CNT 供体级 ARPC2 mean log1p(CP10K) 为 PSC 中位 1.3785（n=4）与 nonPSC 中位 1.2588（n=4），Mann–Whitney P=0.4705，未见显著差异。IL17 样本没有混入该 Vehicle 主比较。

### GSE136103

Scanpy 标志基因注释识别了胆管上皮、肝星状、内皮、肝细胞和免疫群。患者级 ARPC2 比较未显著：胆管上皮健康/肝硬化中位 0.9197/1.0509，P=0.6650；肝星状细胞 1.7714/1.4478，P=0.3123。

## 论文定位与边界

Figure B/C 最适合主文，Figure A 可作为 PSC/PBC/健康背景但应说明阴性总体检验和 QC 异常，Figure D 用于细胞定位，Figure E 更适合支持性材料。数据支持 ARPC2 与人肝纤维化分期相关，并可定位于胆管、肝星状及其他肝细胞群；不能单独证明 AA 直接靶向 ARPC2、不能证明 PSC/PBC 特异性因果机制，也不能替代动物、TPP/PELSA 和功能实验。


## Zenodo PSC 纤维化分期队列

Zenodo 13990103 包含 PSC 16、PBC 15 和 MASLD 16 个样本；没有健康对照，因此未进行健康组比较。PSC 内 ARPC2 与纤维化分期的 Spearman ρ=0.0840，P=0.757，FDR=0.7979。该结果不支持 ARPC2 在此 PSC 队列中与分期存在显著单调关系。MRTF/SRF proxy、SNAI2 和候选基因结果见 `results/tables/zenodo_psc_results.xlsx`；proxy 是表达代理指标，不是 MRTF-A 核转位或直接 SRF 结合测量。

GSE247128 已完成 GEO 元数据筛选：包含 PBC/PSC 单细胞/单核文库，但无空间文件、无健康对照和无分期字段，因此未纳入定量主分析。
