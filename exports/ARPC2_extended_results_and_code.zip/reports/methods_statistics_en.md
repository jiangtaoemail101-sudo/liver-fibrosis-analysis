# Statistical and bioinformatic methods

Expression values were retained in their source scale for GEO microarray analyses. GEO platform annotations were used to map probe identifiers to HGNC symbols; duplicate probes were summarized by the median. The PSC paired a/b samples in GSE159676 were collapsed within the labelled independent donor before inference.

For the Zenodo record 13990103, integer count matrices were converted to log2(CPM+1) after library-size normalization. The primary PSC analysis used Spearman correlation between each gene and the supplied fibrosis stage. Candidate-gene P values were adjusted by Benjamini–Hochberg correction across the prespecified candidate set. No healthy control was imputed because none was present in the clinical table.

MRTF/SRF and EMT scores are exploratory expression proxies. The MRTF/SRF proxy is the mean of patient-wise z scores for detected contractile/ECM candidates; it does not measure MRTF-A nuclear translocation, SRF protein activity, chromatin binding or direct transcriptional regulation. The EMT proxy is similarly an expression summary and is sensitive to cell composition.

For single-cell analyses, cells were sampled for visualization, while disease comparisons were performed on patient-level summaries. Cell numbers were never used as independent patient counts. All figures read P values and effect estimates from generated result tables, and every exported figure was checked in PNG/PDF/SVG/TIFF form.
