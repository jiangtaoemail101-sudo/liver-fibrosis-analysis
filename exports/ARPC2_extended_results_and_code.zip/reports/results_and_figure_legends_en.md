## Results draft

GSE159676 (GPL6244) contained 33 GEO samples: 6 healthy livers, 12 PSC samples representing six paired a/b specimens, 3 PBC samples and 12 samples from other liver diseases. Paired PSC specimens were summarized within donor. ARPC2 expression did not differ among healthy (n=6), PBC (n=3) and PSC (n=6) donors by Kruskal–Wallis testing (H=0.5250, P=0.7691). One extreme raw value was retained and documented in the QC table.

In GSE84044, a chronic hepatitis B rather than cholestatic liver cohort, ARPC2 was positively associated with Scheuer fibrosis stage (n=124, Spearman rho=0.4397, P=3.24e-07). COL3A1, KRT19 and COL1A1 remained associated after Benjamini–Hochberg adjustment, whereas ACTA2, FN1, KRT7, MKL1 and SRF did not.

In the GSE239283 vehicle/CNT organoid samples, donor-level ARPC2 did not differ between PSC and non-PSC organoids (n=4 per group; medians 1.3785 and 1.2588; Mann–Whitney P=0.4705). In GSE136103, Scanpy marker annotation identified cholangiocyte and hepatic stellate populations in human liver libraries. Patient-level ARPC2 comparisons were not significant in cholangiocytes (P=0.6650) or hepatic stellate cells (P=0.3123).

## Figure legends

**Figure A. ARPC2 expression in healthy, PBC and PSC human liver (GSE159676).** Boxes show donor-level expression and points show independent donors; paired PSC a/b specimens were summarized within donor. Overall Kruskal–Wallis H=0.5250, P=0.7691. The extreme raw value in GSM4837495 was retained and documented.

**Figure B. ARPC2 across Scheuer fibrosis stages in chronic hepatitis B liver (GSE84044).** Points are individual liver samples; Spearman rho=0.4397, n=124, P=3.24e-07. This is not a PSC/PBC cohort.

**Figure C. Stage correlations of ARPC2 and fibrosis/cholangiocyte genes.** Heatmap colors represent Spearman coefficients for ARPC2, ACTA2, COL1A1, COL3A1, FN1, KRT7, KRT19, MKL1 and SRF; FDR uses Benjamini–Hochberg correction.

**Figure D. ARPC2 in human liver single-cell RNA-seq (GSE136103).** Scanpy UMAP and marker heatmap show human liver cells after library QC and capped sampling for visualization. Blood/PBMC and mouse samples were excluded; disease comparisons used patient-level pseudobulk summaries.

**Figure E. ARPC2 in vehicle/CNT bile duct organoids (GSE239283).** Each point is one donor (four PSC and four non-PSC donors); donor-level Mann–Whitney P=0.4705.


## Zenodo PSC fibrosis cohort

Zenodo 13990103 contained PSC (n=16), PBC (n=15) and MASLD (n=16) samples without a healthy control. Within PSC, ARPC2 was not associated with fibrosis stage (Spearman rho=0.0840, P=0.757, FDR=0.7979). The MRTF/SRF proxy and SNAI2 results are in `results/tables/zenodo_psc_results.xlsx`; the proxy is an expression summary and not a measurement of MRTF-A nuclear localization or direct SRF binding. GSE247128 was screened as PBC/PSC single-cell/single-nucleus data, but no spatial files, healthy controls or fibrosis-stage field were available, so it was not included in quantitative inference.
