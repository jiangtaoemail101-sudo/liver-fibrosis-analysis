#!/usr/bin/env python3
"""ARPC2 analysis for parsed GEO expression matrices.

All group labels are inferred from the downloaded sample metadata and are
written to the output. Ambiguous samples remain ``unresolved`` and are never
silently assigned to a group.
"""
from __future__ import annotations
import argparse
import gzip
import json
import re
import sys
from io import StringIO
from pathlib import Path
from urllib.request import Request, urlopen

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy.stats import kruskal, mannwhitneyu, spearmanr
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parents[1]
GENES = ["ARPC2", "ACTA2", "COL1A1", "COL3A1", "FN1", "KRT7", "KRT19", "MKL1", "SRF"]
COLORS = {"control": "#4C78A8", "pbc": "#F58518", "psc": "#E45756", "unresolved": "#9E9E9E"}

def metadata_text(row: pd.Series) -> str:
    return " ".join(str(x) for x in row.tolist() if pd.notna(x)).lower()

def infer_group(accession: str, text: str) -> str:
    if accession == "GSE159676":
        if re.search(r"primary\s+sclerosing|\bpsc\b", text): return "psc"
        if re.search(r"primary\s+biliary|\bpbc\b", text): return "pbc"
        if re.search(r"healthy|normal|control|non.?diseased", text): return "control"
    return "unresolved"

def independent_unit_159676(title: str, sample_id: str) -> str:
    match = re.search(r"(?:LTH|PSC)_(\d+)", title)
    if match:
        prefix = "PSC" if "PSC_" in title else "LTH"
        return f"{prefix}_{match.group(1)}"
    match = re.search(r"primary[_ ]+biliary[_ ]+cirrhosis[_ ]+(\d+)", title, flags=re.I)
    if match: return f"PBC_{match.group(1)}"
    return sample_id

def disease_text_159676(row: pd.Series) -> str:
    columns = ["Sample_title", "Sample_characteristics_ch1", "Sample_source_name_ch1", "Sample_description", "condition"]
    return " ".join(str(row.get(column, "")) for column in columns).lower()

def infer_stage(text: str):
    patterns = [
        r"scheuer\s+score\s*[:=]?\s*g[0-4]s([0-4])",
        r"scheuer(?:\s+fibrosis)?\s*(?:stage)?\s*[:=]?\s*([0-4])",
        r"fibrosis\s*(?:stage|staging)\s*[:=]?\s*([0-4])",
        r"(?:stage|staging)\s*[:=]?\s*([0-4])\b",
        r"\bf([0-4])\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.I)
        if match: return int(match.group(1))
    return np.nan

def annotation_url(platform: str) -> str:
    match = re.fullmatch(r"GPL(\d+)", platform)
    if not match: raise ValueError(f"Invalid platform ID: {platform}")
    digits = match.group(1)
    group = f"GPL{digits[0]}nnn" if len(digits) > 3 else "GPLnnn"
    return f"https://ftp.ncbi.nlm.nih.gov/geo/platforms/{group}/GPL{digits}/annot/GPL{digits}.annot.gz"

def read_gpl(platform: str) -> pd.DataFrame:
    raw = ROOT / "data" / "raw" / f"{platform}.annot.gz"
    if not raw.exists():
        request = Request(annotation_url(platform), headers={"User-Agent": "ARPC2-GEO-reproducible-analysis/1.0"})
        with urlopen(request, timeout=60) as source, raw.open("wb") as target:
            target.write(source.read())
    lines, table, active = [], [], False
    with gzip.open(raw, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if line.rstrip("\n") == "!platform_table_begin": active = True; continue
            if line.rstrip("\n") == "!platform_table_end": break
            if active: table.append(line)
    if not table: raise ValueError(f"No platform annotation table found: {platform}")
    return pd.read_csv(StringIO("".join(table)), sep="\t", dtype=str, na_values=["", "NA", "null"], low_memory=False)

def gene_map(matrix: pd.DataFrame, platform: str | None) -> pd.DataFrame:
    index = matrix.index.astype(str)
    by_symbol: dict[str, list[int]] = {}
    if platform:
        annotation = read_gpl(platform)
        id_col = annotation.columns[0]
        candidates = [c for c in annotation.columns if re.search(r"gene.?symbol|symbol$|gene_assignment|gene assignment", c, re.I)]
        if candidates:
            symbols = annotation[candidates[0]].fillna("").astype(str)
            lookup = dict(zip(annotation[id_col].astype(str), symbols))
            for i, probe in enumerate(index):
                raw = lookup.get(probe, "")
                for symbol in re.split(r"///|//|;|,|\s+", raw.upper()):
                    symbol = symbol.strip()
                    if symbol in GENES: by_symbol.setdefault(symbol, []).append(i)
    for gene in GENES:
        exact = np.flatnonzero(index.str.upper().to_numpy() == gene)
        if len(exact): by_symbol.setdefault(gene, []).extend(exact.tolist())
    out = {}
    for gene, positions in by_symbol.items():
        unique = sorted(set(positions))
        out[gene] = matrix.iloc[unique].median(axis=0, skipna=True)
    return pd.DataFrame(out).T.reindex(GENES)

def save_figure(fig, stem: Path):
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"), dpi=300, bbox_inches="tight")

def analyze_159676(matrix, samples, platform):
    samples = samples.copy()
    samples["analysis_group"] = [infer_group("GSE159676", disease_text_159676(row)) for _, row in samples.iterrows()]
    samples["independent_unit"] = [independent_unit_159676(str(row.get("Sample_title", "")), sample_id) for sample_id, row in samples.iterrows()]
    samples["potential_duplicate"] = samples.duplicated("independent_unit", keep=False)
    expression = gene_map(matrix, platform)
    expression.to_csv(ROOT / "data/processed/GSE159676/gene_expression_sample.csv")
    independent = expression.T.join(samples[["analysis_group", "independent_unit"]]).groupby("independent_unit").median(numeric_only=True).T
    independent_groups = samples.groupby("independent_unit")["analysis_group"].first()
    independent.to_csv(ROOT / "data/processed/GSE159676/gene_expression.csv")
    samples.to_csv(ROOT / "data/processed/GSE159676/sample_metadata_annotated.csv")
    stats_rows, values = [], []
    for group in ("control", "pbc", "psc"):
        subset = independent.loc["ARPC2", independent_groups.eq(group)].dropna()
        values.extend({"group": group, "value": float(value)} for value in subset)
        stats_rows.append({"dataset": "GSE159676", "gene": "ARPC2", "unit": "independent_donor", "group": group, "n": len(subset), "mean": subset.mean(), "median": subset.median(), "min": subset.min(), "max": subset.max()})
    groups = {g: independent.loc["ARPC2", independent_groups.eq(g)].dropna() for g in ("control", "pbc", "psc")}
    available = [x for x in groups.values() if len(x) >= 2]
    if len(available) >= 2:
        test = kruskal(*available)
        stats_rows.append({"dataset": "GSE159676", "gene": "ARPC2", "unit": "independent_donor", "test": "Kruskal-Wallis", "statistic": test.statistic, "p_value": test.pvalue, "n_groups": len(available)})
    else:
        stats_rows.append({"dataset": "GSE159676", "gene": "ARPC2", "unit": "independent_donor", "test": "Kruskal-Wallis", "reason": "fewer than two groups with n >= 2"})
    for left, right in (("control", "pbc"), ("control", "psc"), ("pbc", "psc")):
        if len(groups[left]) >= 1 and len(groups[right]) >= 1:
            result = mannwhitneyu(groups[left], groups[right], alternative="two-sided", method="asymptotic")
            stats_rows.append({"dataset": "GSE159676", "gene": "ARPC2", "unit": "independent_donor", "test": "Mann-Whitney U", "comparison": f"{left} vs {right}", "n_left": len(groups[left]), "n_right": len(groups[right]), "median_left": groups[left].median(), "median_right": groups[right].median(), "median_difference": groups[right].median() - groups[left].median(), "statistic": result.statistic, "p_value": result.pvalue})
    stats_table = pd.DataFrame(stats_rows)
    stats_table.to_csv(ROOT / "results/tables/GSE159676_ARPC2_statistics.csv", index=False)
    with pd.ExcelWriter(ROOT / "results/tables/GSE159676_ARPC2_statistics.xlsx") as writer:
        stats_table.to_excel(writer, sheet_name="ARPC2_statistics", index=False)
        samples.to_excel(writer, sheet_name="sample_metadata", index=True)
    plot_df = pd.DataFrame(values)
    regular = plot_df.loc[plot_df.value < 100]
    extreme = plot_df.loc[plot_df.value >= 100]
    fig, (top, bottom) = plt.subplots(2, 1, sharex=True, figsize=(4.8, 5.0), gridspec_kw={"height_ratios": [1, 3], "hspace": 0.05})
    order = ["control", "pbc", "psc"]
    sns.boxplot(data=regular, x="group", y="value", hue="group", order=order, hue_order=order, palette=COLORS, legend=False, showfliers=False, ax=bottom)
    sns.stripplot(data=regular, x="group", y="value", order=order, color="#222222", size=4, jitter=.16, ax=bottom)
    if not extreme.empty:
        x_positions = {group: i for i, group in enumerate(order)}
        rng = np.random.default_rng(2026)
        for _, item in extreme.iterrows():
            top.scatter(x_positions[item.group] + rng.uniform(-.08, .08), item.value, color="#222222", s=28, zorder=5)
        top.set_ylim(max(100, extreme.value.min() * .7), extreme.value.max() * 1.35)
        top.text(.99, .9, "extreme raw value retained", transform=top.transAxes, ha="right", va="top", fontsize=8)
    else:
        top.set_visible(False)
    bottom.set_ylim(regular.value.min() * .97, regular.value.max() * 1.04)
    bottom.set(xlabel="Disease group", ylabel="ARPC2 expression", title="GSE159676")
    top.spines["bottom"].set_visible(False); bottom.spines["top"].set_visible(False)
    top.tick_params(labeltop=False, bottom=False); bottom.xaxis.tick_bottom()
    d = .012
    kwargs = dict(transform=top.transAxes, color="k", clip_on=False, linewidth=1)
    top.plot((-d, +d), (-d, +d), **kwargs); top.plot((1-d, 1+d), (-d, +d), **kwargs)
    kwargs.update(transform=bottom.transAxes)
    bottom.plot((-d, +d), (1-d, 1+d), **kwargs); bottom.plot((1-d, 1+d), (1-d, 1+d), **kwargs)
    sns.despine(ax=bottom)
    save_figure(fig, ROOT / "results/figures/Figure_A_GSE159676_ARPC2")
    plt.close(fig)

def analyze_84044(matrix, samples, platform):
    samples = samples.copy()
    samples["scheuer_stage"] = [infer_stage(metadata_text(row)) for _, row in samples.iterrows()]
    samples["patient_id"] = [re.search(r"patient\s+(\d+)", metadata_text(row), flags=re.I).group(1) if re.search(r"patient\s+(\d+)", metadata_text(row), flags=re.I) else "unresolved" for _, row in samples.iterrows()]
    samples["potential_duplicate"] = samples.duplicated("patient_id", keep=False)
    expression = gene_map(matrix, platform)
    expression.to_csv(ROOT / "data/processed/GSE84044/gene_expression.csv")
    samples.to_csv(ROOT / "data/processed/GSE84044/sample_metadata_annotated.csv")
    keep = samples["scheuer_stage"].notna() & expression.loc["ARPC2"].notna()
    if keep.sum() >= 3 and samples.loc[keep, "scheuer_stage"].nunique() >= 2:
        rho, p = spearmanr(samples.loc[keep, "scheuer_stage"], expression.loc["ARPC2", keep])
        row = {"dataset": "GSE84044", "gene": "ARPC2", "n": int(keep.sum()), "spearman_rho": rho, "p_value": p, "stage_min": samples.loc[keep, "scheuer_stage"].min(), "stage_max": samples.loc[keep, "scheuer_stage"].max()}
    else:
        row = {"dataset": "GSE84044", "gene": "ARPC2", "n": int(keep.sum()), "reason": "insufficient unambiguous Scheuer stage metadata"}
    stage_table = pd.DataFrame([row])
    stage_table.to_csv(ROOT / "results/tables/GSE84044_ARPC2_stage_correlation.csv", index=False)
    stats = []
    for gene in GENES:
        if gene not in expression.index: continue
        valid = keep & expression.loc[gene].notna()
        if valid.sum() >= 3 and samples.loc[valid, "scheuer_stage"].nunique() >= 2:
            rho, p = spearmanr(samples.loc[valid, "scheuer_stage"], expression.loc[gene, valid])
            stats.append({"gene": gene, "n": int(valid.sum()), "spearman_rho": rho, "p_value": p})
    table = pd.DataFrame(stats)
    if not table.empty:
        table["fdr_bh"] = multipletests(table["p_value"], method="fdr_bh")[1]
    table.to_csv(ROOT / "results/tables/GSE84044_fibrosis_gene_correlations.csv", index=False)
    with pd.ExcelWriter(ROOT / "results/tables/GSE84044_statistics.xlsx") as writer:
        stage_table.to_excel(writer, sheet_name="ARPC2_stage", index=False)
        table.to_excel(writer, sheet_name="gene_correlations", index=False)
        samples.to_excel(writer, sheet_name="sample_metadata", index=True)
    if keep.sum() >= 3:
        plot_data = pd.DataFrame({"stage": samples.loc[keep, "scheuer_stage"].astype(int).to_numpy(), "ARPC2": expression.loc["ARPC2", keep].to_numpy()})
        fig, ax = plt.subplots(figsize=(5.2, 4.2))
        sns.boxplot(data=plot_data, x="stage", y="ARPC2", color="#72B7B2", showfliers=False, ax=ax)
        sns.stripplot(data=plot_data, x="stage", y="ARPC2", color="#222222", size=4, jitter=.16, ax=ax)
        ax.set(xlabel="Scheuer fibrosis stage", ylabel="ARPC2 expression", title="GSE84044")
        sns.despine()
        save_figure(fig, ROOT / "results/figures/Figure_B_GSE84044_ARPC2_stage")
        plt.close(fig)
        if not table.empty:
            heat = table.set_index("gene")[["spearman_rho"]].reindex(GENES).dropna()
            fig, ax = plt.subplots(figsize=(3.4, max(2.5, len(heat) * .35)))
            sns.heatmap(heat, cmap="vlag", center=0, annot=True, fmt=".2f", cbar_kws={"label": "Spearman rho"}, ax=ax)
            ax.set(xlabel="", ylabel="")
            save_figure(fig, ROOT / "results/figures/Figure_C_GSE84044_gene_correlations")
            plt.close(fig)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("accession", choices=["GSE159676", "GSE84044"])
    args = parser.parse_args()
    base = ROOT / "data/processed" / args.accession
    matrix = pd.read_csv(base / "expression_matrix.csv.gz", index_col=0)
    samples = pd.read_csv(base / "sample_metadata.csv", index_col=0)
    platforms = sorted(set(samples.get("platform_id", pd.Series(dtype=str)).dropna()))
    platform = platforms[0] if len(platforms) == 1 and platforms[0] else None
    if args.accession == "GSE159676": analyze_159676(matrix, samples, platform)
    else: analyze_84044(matrix, samples, platform)
    print(f"Completed {args.accession}; platform={platform or 'unresolved'}")

if __name__ == "__main__":
    try: main()
    except Exception as exc:
        print(f"Analysis failed without imputing data: {exc!r}", file=sys.stderr)
        raise
