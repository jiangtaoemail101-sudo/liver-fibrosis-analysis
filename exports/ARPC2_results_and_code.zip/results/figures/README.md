# Figure files

Use the PNG files for quick preview, PDF/SVG for vector editing, and TIFF for 600-dpi submission output.

- [Figure A preview (PNG)](Figure_A_GSE159676_ARPC2.png) · [PDF](Figure_A_GSE159676_ARPC2.pdf) · [SVG](Figure_A_GSE159676_ARPC2.svg) · [600-dpi TIFF](Figure_A_GSE159676_ARPC2.tiff)
- [Figure B preview (PNG)](Figure_B_GSE84044_ARPC2_stage.png) · [PDF](Figure_B_GSE84044_ARPC2_stage.pdf) · [SVG](Figure_B_GSE84044_ARPC2_stage.svg) · [600-dpi TIFF](Figure_B_GSE84044_ARPC2_stage.tiff)
- [Figure C preview (PNG)](Figure_C_GSE84044_gene_correlations.png) · [PDF](Figure_C_GSE84044_gene_correlations.pdf) · [SVG](Figure_C_GSE84044_gene_correlations.svg) · [600-dpi TIFF](Figure_C_GSE84044_gene_correlations.tiff)
- [Figure D preview (PNG)](Figure_D_GSE136103_ARPC2_UMAP_DotPlot.png) · [PDF](Figure_D_GSE136103_ARPC2_UMAP_DotPlot.pdf) · [SVG](Figure_D_GSE136103_ARPC2_UMAP_DotPlot.svg) · [600-dpi TIFF](Figure_D_GSE136103_ARPC2_UMAP_DotPlot.tiff)
- [Figure E preview (PNG)](Figure_E_GSE239283_ARPC2_vehicle.png) · [PDF](Figure_E_GSE239283_ARPC2_vehicle.pdf) · [SVG](Figure_E_GSE239283_ARPC2_vehicle.svg) · [600-dpi TIFF](Figure_E_GSE239283_ARPC2_vehicle.tiff)
