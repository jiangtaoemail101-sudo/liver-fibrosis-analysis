# ARPC2 GEO public-transcriptome analysis

This project contains a reproducible analysis of ARPC2 in the requested human GEO datasets for cholestatic liver-fibrosis research. It uses only official NCBI GEO files and records SHA256 hashes in `data/raw/download_manifest.json` and the supplemental-data manifests.

## One-command rerun

The current cloud environment has Python 3.12, R 4.4 and Scanpy installed outside the checkout. From the project directory run:

```bash
bash run_all.sh
```

The script downloads official files, parses sample metadata and platform annotation, runs donor-aware statistics, generates all figures, and writes the Chinese report and English Results/Figure legends. It does not use GSE61260.

## Reproducibility and statistical units

- GSE159676 uses GPL6244 annotation, retains all 33 samples in the metadata, excludes the 12 unrelated liver diseases from the requested three-group comparison, and collapses the six PSC a/b pairs to six independent PSC donors.
- GSE84044 uses GPL570 annotation and parses the `Scheuer score: GxSy` metadata. It is a chronic hepatitis B cohort, not a PSC/PBC or cholestatic cohort.
- GSE239283 uses official 10x matrices and metadata. The primary comparison is Vehicle/CNT only and uses one donor-level summary per donor (four PSC and four nonPSC donors); cells are not treated as independent donors.
- GSE136103 extracts the official RAW tar, keeps human healthy/cirrhotic liver libraries, excludes blood/PBMC and mouse libraries, uses Scanpy for marker-based UMAP, and tests disease differences on patient-level pseudobulk summaries.

An extreme ARPC2 value in GSM4837495 in GSE159676 is retained and explicitly flagged in `results/tables/sample_qc_flags.csv`; no sample was removed to increase significance.

## Main outputs

- Raw downloads and source manifests: `data/raw/`
- Parsed matrices and metadata: `data/processed/`
- Complete scripts: `scripts/`
- CSV/Excel statistics: `results/tables/`
- PDF, SVG, 600-dpi TIFF and PNG figures: `results/figures/`
- Clickable figure index: [`results/figures/README.md`](results/figures/README.md)
- Chinese report: `reports/analysis_report_zh.md`
- English Results and figure legends: `reports/results_and_figure_legends_en.md`

The public data support an association between ARPC2 and fibrosis stage in the HBV cohort and show its distribution across human liver cell populations. They cannot by themselves establish that asiatic acid directly targets ARPC2, prove PSC/PBC-specific causality, or replace the animal, TPP/PELSA and functional experiments.
